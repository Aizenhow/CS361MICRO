import requests

def repeat_client():
    while True:
        main()
        choice = input("Do you want to filter more cards? (yes/no): ").strip().lower()
        if choice != "yes":
            break

def get_filter_criteria():
    print("Enter filter criteria for cards. Leave blank to ignore a criterion.")
    color = input("Color: ").strip() or None
    if color and "," in color:
        colors = [c.strip() for c in color.split(",")]
        color = colors
    type_line = input("Type Line: ").strip().replace("-", "—") or None
    rarity = input("Rarity: ").strip() or None
    mana_cost = input("Mana Cost: ").strip() or None
    set_name = input("Set Name: ").strip() or None
    conditions = {}
    if color:
        conditions["colors"] = color
    if type_line:
        conditions["type_line"] = type_line
    if rarity:
        conditions["rarity"] = rarity
    if mana_cost:
        conditions["mana_cost"] = mana_cost
    if set_name:
        conditions["set_name"] = set_name
    print("Filter conditions:", conditions)  # Print the constructed conditions
    return conditions


def filter_cards(conditions):
    url = 'http://127.0.0.1:5000/filter-cards'
    response = requests.post(url, json={"filter_conditions": conditions})
    if response.status_code == 200:
        return response.json()
    else:
        print("Error:", response.status_code)
        return []

def main():
    conditions = get_filter_criteria()
    filtered_cards = filter_cards(conditions)
    if filtered_cards:
        print("\nFiltered cards:")
        for card in filtered_cards:
            print(card["name"])  # Print only the name of the card
    else:
        print("No cards matched the criteria.")

if __name__ == "__main__":
    repeat_client()
