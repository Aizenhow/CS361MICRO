from flask import Flask, request, jsonify
import requests
from urllib.parse import quote

app = Flask(__name__)

def filter_cards(cards, conditions):
    print("Filtering cards with conditions:", conditions)
    filtered_cards = []
    for card in cards:
        match = True
        for key, value in conditions.items():
            if key == "colors":
                card_colors = card.get("colors", [])
                input_colors = [c.strip() for c in value]
                if not set(input_colors).issubset(set(card_colors)):
                    match = False
                    break
            elif key == "type_line":
                card_type_line = card.get("type_line", "").lower()
                if value.lower() not in card_type_line:
                    match = False
                    break
            elif key == "rarity" and value.lower() != card.get("rarity", "").lower():
                match = False
                break
            elif key == "mana_cost" and value.lower() != card.get("mana_cost", "").lower():
                match = False
                break
            elif key == "set_name" and value.lower() != card.get("set_name", "").lower():
                match = False
                break
        if match:
            filtered_cards.append(card)
    return filtered_cards

@app.route('/filter-cards', methods=['POST'])
def handle_filter_cards():
    data = request.json
    filter_conditions = data['filter_conditions']
    url = 'https://api.scryfall.com/cards/search?q='
    mana_cost_specified = 'mana_cost' in filter_conditions and filter_conditions['mana_cost']

    for key, value in filter_conditions.items():
        if key == 'set_name':
            # Format set_name for the URL with URL encoding
            url += f'set%3A"{quote(value)}" '  # Use quote to URL encode the value
        elif key != 'mana_cost' or mana_cost_specified:
            url += f'{key}:"{value}" '

    print("Generated URL:", url)

    filtered_cards = []
    while url:
        response = requests.get(url.strip())
        print("Response status code:", response.status_code)
        if response.status_code == 200:
            data = response.json()
            cards = data['data']
            filtered_cards.extend(filter_cards(cards, filter_conditions))
            url = data.get('next_page')
        else:
            break

    return jsonify(filtered_cards)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
